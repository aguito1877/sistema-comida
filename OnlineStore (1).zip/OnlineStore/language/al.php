<?php
$inicio="Zuhause";
$producto="Produkt";
$english="Englisch";
$español="Spanisch";
$frances="Frances";
$aleman="Deutsch";

//registro

$registro="Benutzer Registration";
$al_registrarse="Nach der Registrierung erhalten Sie Benachrichtigungen über unsere neuesten Mahlzeiten und Angebote in unserem Geschäft.";
$debera="Sie müssen alle Felder ausfüllen, um sich zu registrieren";
$nit="Geben Sie Ihre NIT-Nummer ein";
$Inusuario="Geben Sie Ihren Benutzernamen ein";
$Innombre="Geben Sie Ihre Namen ein";
$Inapellido="Geben Sie Ihren Nachnamen ein";
$Incontraseña="Geben Sie ein Passwort ein";
$Indireccion="Geben Sie Ihre Adresse ein";
$Intelefono="Trage deine Telefonnummer ein";
$Inemail="Geben sie ihre E-Mail Adresse ein";
$inregi="Check in";

$nit_err="Geben Sie Ihre NIT-Nummer ein. Nur Zahlen und Bindestriche (-)";
$Inusuario_err="Geben Sie Ihren Namen ein Maximal 9 Zeichen (nur Buchstaben)";
$Innombre_err="Geben Sie Ihre Namen ein. (Nur Buchstaben)";
$Inapellido_err="Geben Sie Ihren Nachnamen ein (nur Buchstaben)";
$Incontraseña_err="Geben Sie Ihr Passwort richtig ein";
$Indireccion_err="Geben Sie die Adresse ein, in der sich derzeit befindet";
$Intelefono_err="Geben Sie Ihre Telefonnummer ein. Mindestens 8 Ziffern, höchstens 11";
$Inemail_err="Geben Sie Ihre E-Mail-Adresse ein";

//pedido
$confirp="Geben Sie Ihre E-Mail-Adresse ein";

//admin
$panel="Admin Panel";
$prs="Produkte";
$prove="Lieferanten";
$cat="Kategorien";
$ad="Admin";
$ped="Bestellungen";
$agreg="Fügen Sie ein neues Produkt hinzu";
$codpr="Produktcode";
$nompr="Produktname";
$ctg="Kategorie";
$prec="Preis";
$sz="Würze";
$tip="Typ Essen";
$canpl="Anzahl der Gerichte";
$provd="Verkäufer";
$img="Produktabbildung";
$fimg="Unterstützte Bildformate: PNG, JPG, GIF, JPEG";
$agt="Zum Shop hinzufügen";
$elim="Löschen Sie ein Produkt";
$Eliminar="Entfernen";
$actu="Produktdaten aktualisieren";
$codg="Code";
$nob="Vorname";
$uni="Einheiten";
$op="Optionen";
$tipoc="Typ Essen";
$drc="Adresse";
$tlf="Telefonnummer";
$correle="E-Mail";
$anpro="Anbieter hinzufügen";
$elprov="Anbieter löschen";
$actupro="Providerdaten aktualisieren";

$agcat="Kategorie hinzufügen";
$elicat="Löschen Sie eine Kategorie";
$elimcat="Kategorie löschen";
$actucat="Kategorie aktualisieren";
$despr="Beschreibung";
$agadmini="Administrator hinzufügen";
$eliad="Administrator löschen";
$adtras="Administratoren";
$eliped="Bestellung löschen";
$pedd="Bestellungen";
$actupedd="Auftragsstatus aktualisieren";
$feca="Datum";
$clte="Kunde";
$dsct="Rabatt";
$ttl="Total";
$esdo="Zustand";


//navbar
$confp=" Bestellung bestätigen";
$vac="Warenkorb leeren";
$regt="Registrierung";
$inise="Melden Sie sich bei an Fast Lunch";
$esnob="Schreibe deinen Namen";
$contr="Passwort";
$escontr="Geben Sie Ihr Passwort ein";
$como="Wie wirst du dich einloggen?";
$usu="Benutzername";
$adtr="Administrator";
$inises="Einloggen";
$canc="Abbrechen";
$elpr="Das Produkt wurde in den Warenkorb gelegt";
$acep="Akzeptiere";
$qcers="Möchten Sie sich abmelden?";
$cers="Abmelden";

//infpro
$modl="Modell";
$mara="Brand";
$rgti="Zurück zum Laden";
$adca="In den Warenkorb legen";









//productos
$categori="Kategorien";
$todos="Alle Produkte";

//index
$Bienvenido="Willkommen in unserer Online-Bewerbung, hier finden Sie eine große Auswahl an Gerichten in Ihrer Nähe.";








$cambiarIdioma="Sprache wechseln"



?>
