<?php
$inicio="Inicio";
$producto="Producto";
$english="Ingles";
$español="Español";
$frances="Frances";
$aleman="Aleman";

//registrarse
$registro="Registro de usuarios";
$al_registrarse="Al registrarse recibira notificaciones de nuestras comidas y ofertas más recientes en nuestra tienda.";
$debera="Debera de llenar todos los campos para registrarse";
$nit="Ingrese su número de NIT";
$Inusuario="Ingrese su nombre de usuario";
$Innombre="Ingrese sus nombres";
$Inapellido="Ingrese sus apellidos";
$Incontraseña="Introduzca una contraseña";
$Indireccion="Ingrese su dirección";
$Intelefono="Ingrese su número telefónico";
$Inemail="Ingrese su Email";
$inregi="Registrarse";

$nit_err="Ingrese su número de NIT. Solamente números y guiones(-)";
$Inusuario_err="Ingrese su nombre. Máximo 9 caracteres (solamente letras)";
$Innombre_err="Ingrese sus nombres.(solamente letras)";
$Inapellido_err="Ingrese sus apellido(solamente letras)";
$Incontraseña_err="Defina una contraseña para iniciar sesión";
$Indireccion_err="Ingrese la direción en la reside actualmente";
$Intelefono_err="Ingrese su número telefónico. Mínimo 8 digitos máximo 11";
$Inemail_err="Ingrese la dirección de su Email";

//pedido
$confirp="Confirmar pedido";

//admin
$panel="Panel de administración";
$prs="Productos";
$prove="Proveedores";
$cat="Categorías";
$ad="Admin";
$ped="Pedidos";
$agreg="Agregar un producto nuevo";
$codpr="Código de producto";
$nompr="Nombre de producto";
$ctg="Categoría";
$prec="Precio";
$sz="Sazón";
$tip="Tipo Comida";
$canpl="Cantidad de Platos";
$provd="Proveedor";
$img="Imagen de producto";
$fimg="Formato de imagenes admitido png, jpg, gif, jpeg";
$agt="Agregar a la tienda";
$elim="Eliminar un producto";
$Eliminar="Eliminar";
$actu="Actualizar datos de producto";
$codg="Código";
$nob="Nombre";
$uni="Unidades";
$op="Opciones";
$tipoc="Tipo Comida";
$drc="Dirección";
$tlf="Teléfono";
$correle="Correo Electrónico";
$anpro="Añadir proveedor";
$elprov="Eliminar proveedor";
$actupro="Actualizar datos de proveedor";

$agcat="Agregar categoría";
$elicat="Eliminar una categoría";
$elimcat="Eliminar categoría";
$actucat="Actualizar categoría";
$despr="Descripción";
$agadmini="Agregar administrador";
$eliad="Eliminar administrador";
$adtras="Administradores";
$eliped="Eliminar pedido";
$pedd="Pedidos";
$actupedd="Actualizar estado de pedido";
$feca="Fecha";
$clte="Cliente";
$dsct="Descuento";
$ttl="Total";
$esdo="Estado";
$actupro="";
$actupro="";

//navbar
$confp=" Confirmar pedido";
$vac="Vaciar carrito";
$regt="Registro";
$inise="Iniciar sesión en Fast Lunch";
$esnob="Escribe tu nombre";
$contr="Contraseña";
$escontr="Escribe tu contraseña";
$como="¿Cómo iniciaras sesión?";
$usu="Usuario";
$adtr="Administrador";
$inises="Iniciar sesión";
$canc="Cancelar";
$elpr="El producto se añadio al carrito";
$acep="Aceptar";
$qcers="¿Quieres cerrar la sesión?";
$cers="Cerrar la sesión";

//infpro
$modl="Modelo";
$mara="Marca";
$rgti="Regresar a la tienda";
$adca="Añadir al carrito";



//categorias
$categori="Categorías";
$todos="Todos los productos";


//
$admntra="Administración";
$verccom="Ver carrito de compras";
$nvdds="Novedades";
$regtcli="Registrese y hagase cliente de";
$nocomida="No hay comidas registradas en la tienda";
$parareci="para recibir las mejores ofertas en comidas caceras.";
$nuests="Nuestras";
$plati="Platos";



//index
$Bienvenido="Bienvenido a nuestra aplicación en linea, aquí encontrara una gran variedad de comidas cerca de ti.";
$cambiarIdioma="Cambiar Idioma"



?>

