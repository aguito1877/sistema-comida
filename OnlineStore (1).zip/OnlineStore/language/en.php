<?php
$inicio="Start";
$producto="Product";
$english="English";
$español="Spanish";
$frances="French";
$aleman="German";
//registro

$registro="User Registration";
$al_registrarse="Upon registering you will receive notifications of our most recent meals and offers in our store.";
$debera="You must fill in all fields to register";
$nit="Enter your NIT number";
$Inusuario="Enter your username";
$Innombre="Enter your names";
$Inapellido="Enter your last name";
$Incontraseña="Enter a password";
$Indireccion="Enter your address";
$Intelefono="Enter your phone number";
$Inemail="Enter your email";
$inregi="Check in";

$nit_err="Enter your NIT number. Only numbers and hyphens (-)";
$Inusuario_err="Enter your name Maximum 9 characters (only letters)";
$Innombre_err="Enter your names. (Letters only)";
$Inapellido_err="Enter your last name (only letters)";
$Incontraseña_err="Enter your password correctly";
$Indireccion_err="Enter the address in the currently resides";
$Intelefono_err="Enter your phone number. Minimum 8 digits maximum 11";
$Inemail_err="Enter your email address";

//pedido
$confirp="To confirm order";

//admin
$panel="Administration panel";
$prs="Products";
$prove="Suppliers";
$cat="Categories";
$ad="Admin";
$ped="Orders";
$agreg="Add a new product";
$codpr="Product code";
$nompr="Name of product";
$ctg="Category";
$prec="Price";
$sz="Seasoning";
$tip="Food Type";
$canpl="Number of Dishes";
$provd="Provider";
$img="Product image";
$fimg="Supported image format png, jpg, gif, jpeg";
$agt="Add to store";
$elim="Delete a product";
$Eliminar="Delete";


$actu = "Update product data";
$codg = "Code";
$nob = "Name";
$uni = "Units";
$op = "Options";
$tipoc = "Type of Food";
$drc = "Address";
$tlf = "Telephone";
$correle = "Email";
$anpro = "Add provider";
$elprov = "Delete provider";
$actupro = "Update provider data";
$agcat = "Add category";
$elicat = "Delete a category";
$elimcat = "Remove category";
$actucat = "Update category";
$despr = "Description";
$agadmini = "Add administrator";
$eliad = "Delete administrator";
$adtras = "Administrators";
$eliped = "Delete order";
$pedd = "Orders";
$actupedd = "Update order status";
$feca = "Date";
$clte = "Client";
$dsct = "Discount";
$ttl = "Total";
$esdo = "State";

//navbar
$confp = "Confirm order";
$vac = "Empty cart";
$regt = "Registration";
$inise = "Login to ";
$esnob = "Enter your name";
$contr = "Password";
$escontr = "Enter your password";
$como = "How will you log in?";
$usu = "User";
$adtr = "Administrator";
$inises = "Login";
$canc = "Cancel";
$elpr = "The product was added to the cart";
$acep = "Accept";
$qcers = "Do you want to log out?";
$cers = "Log out";
//infpro

$modl = "Model";
$mara = "Brand";
$rgti = "Return to the store";
$adca = "Add to cart";






//productos
$categori="Categorias";
$todos="All the Products";

//index
$Bienvenido="Welcome to our online application, here you will find a wide variety of meals near you.";
$cambiarIdioma="Change Language"



?>


