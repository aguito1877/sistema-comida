<footer>
    <h3 class="text-center">Siguenos en</h3><br>
    <ul class="list-unstyled text-center">
        <a href="#" class="social-icon all-elements-tooltip" data-toggle="tooltip" data-placement="bottom" title="Facebook">
            <img src="assets/icons/social-facebook.png" alt="facebook-icon">
        </a>
        <a href="#" class="social-icon all-elements-tooltip" data-toggle="tooltip" data-placement="bottom" title="Google +">
            <img src="assets/icons/social-googleplus.png" alt="googleplus-icon">
        </a>
        <a href="#" class="social-icon all-elements-tooltip" data-toggle="tooltip" data-placement="bottom" title="Linkedin">
            <img src="assets/icons/social-linkedin.png" alt="linkedin-icon">
        </a>
        <a href="#" class="social-icon all-elements-tooltip" data-toggle="tooltip" data-placement="bottom" title="Pinterest">
            <img src="assets/icons/social-pinterest.png" alt="pinterest-icon">
        </a>
        <a href="#" class="social-icon all-elements-tooltip" data-toggle="tooltip" data-placement="bottom" title="Twitter">
            <img src="assets/icons/social-twitter.png" alt="twitter-icon">
        </a>
    </ul>
    <br><br><br>
    <h5 class="text-center tittles-pages-logo">Fast Luch &copy; <?php echo date("Y");?></h5>
</footer>
